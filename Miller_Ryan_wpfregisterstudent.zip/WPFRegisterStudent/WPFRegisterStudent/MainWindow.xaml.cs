﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace WPFRegisterStudent
{
    public partial class MainWindow : Window
    {
        private List<Course> courses;
        private int totalCredits = 0;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Initialize the courses
            courses = new List<Course>
            {
                new Course("IT 145"),
                new Course("IT 200"),
                new Course("IT 201"),
                new Course("IT 270"),
                new Course("IT 315"),
                new Course("IT 328"),
                new Course("IT 330")
            };

            // Populate the ComboBox with courses
            foreach (var course in courses)
            {
                comboBox.Items.Add(course.getName());
            }

            textBox.Text = "";
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            Course selectedCourse = GetSelectedCourse();

            if (selectedCourse != null)
            {
                if (RegisterCourse(selectedCourse))
                {
                    UpdateUI();
                }
            }
            else
            {
                MessageBox.Show("Please select a course.");
            }
        }

        private Course GetSelectedCourse()
        {
            string selectedCourseName = comboBox.SelectedItem as string;
            foreach (var course in courses)
            {
                if (course.getName() == selectedCourseName)
                {
                    return course;
                }
            }
            return null;
        }

        private bool RegisterCourse(Course selectedCourse)
        {
            if (selectedCourse.IsRegisteredAlready())
            {
                MessageBox.Show("This course is already registered.");
                return false;
            }

            if (totalCredits + 3 > 9) 
            {
                MessageBox.Show("You cannot register for more than 9 credit hours.");
                return false;
            }

            selectedCourse.SetToRegistered();
            totalCredits += 3;

            MessageBox.Show($"Successfully registered for {selectedCourse.getName()}.");
            return true;
        }

        private void UpdateUI()
        {
            textBox.Text = $"Total Credits: {totalCredits}";

            listBox.Items.Clear();
            foreach (var course in courses)
            {
                if (course.IsRegisteredAlready())
                {
                    listBox.Items.Add(course.getName());
                }
            }
        }
    }
}
